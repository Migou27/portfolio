﻿
namespace WinFormsAP_Digicod
{
    partial class Bâtiment_Informatique
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_Valider_Digicode = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_Valider_Motdepasse = new System.Windows.Forms.Button();
            this.btn_DEL = new System.Windows.Forms.Button();
            this.btn_Accueil = new System.Windows.Forms.Button();
            this.tb_Motdepasse = new System.Windows.Forms.TextBox();
            this.tb_Digicode = new System.Windows.Forms.TextBox();
            this.tb_texte = new System.Windows.Forms.TextBox();
            this.btn_Quitter = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_1
            // 
            this.btn_1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_1.Location = new System.Drawing.Point(211, 103);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(62, 50);
            this.btn_1.TabIndex = 0;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_7
            // 
            this.btn_7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_7.Location = new System.Drawing.Point(211, 215);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(62, 50);
            this.btn_7.TabIndex = 1;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = true;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // btn_0
            // 
            this.btn_0.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_0.Location = new System.Drawing.Point(279, 271);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(62, 50);
            this.btn_0.TabIndex = 2;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = true;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // btn_9
            // 
            this.btn_9.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_9.Location = new System.Drawing.Point(347, 215);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(62, 50);
            this.btn_9.TabIndex = 3;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = true;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_8
            // 
            this.btn_8.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_8.Location = new System.Drawing.Point(279, 215);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(62, 50);
            this.btn_8.TabIndex = 4;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = true;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_6
            // 
            this.btn_6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_6.Location = new System.Drawing.Point(347, 159);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(62, 50);
            this.btn_6.TabIndex = 5;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = true;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_3
            // 
            this.btn_3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_3.Location = new System.Drawing.Point(347, 103);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(62, 50);
            this.btn_3.TabIndex = 6;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = true;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_5
            // 
            this.btn_5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_5.Location = new System.Drawing.Point(279, 159);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(62, 50);
            this.btn_5.TabIndex = 7;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_2
            // 
            this.btn_2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_2.Location = new System.Drawing.Point(279, 103);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(62, 50);
            this.btn_2.TabIndex = 2;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_4
            // 
            this.btn_4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_4.Location = new System.Drawing.Point(211, 159);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(62, 50);
            this.btn_4.TabIndex = 9;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_Valider_Digicode
            // 
            this.btn_Valider_Digicode.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Valider_Digicode.Image = global::WinFormsAP_Digicod.Properties.Resources.Fleche_valider3;
            this.btn_Valider_Digicode.Location = new System.Drawing.Point(347, 271);
            this.btn_Valider_Digicode.Name = "btn_Valider_Digicode";
            this.btn_Valider_Digicode.Size = new System.Drawing.Size(62, 50);
            this.btn_Valider_Digicode.TabIndex = 10;
            this.btn_Valider_Digicode.UseVisualStyleBackColor = true;
            this.btn_Valider_Digicode.Click += new System.EventHandler(this.btn_Valider_Digicode_Click_1);
            // 
            // btn_A
            // 
            this.btn_A.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_A.Location = new System.Drawing.Point(34, 456);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(43, 42);
            this.btn_A.TabIndex = 11;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_H
            // 
            this.btn_H.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_H.Location = new System.Drawing.Point(300, 504);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(43, 42);
            this.btn_H.TabIndex = 12;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_G.Location = new System.Drawing.Point(251, 504);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(43, 42);
            this.btn_G.TabIndex = 13;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_O
            // 
            this.btn_O.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_O.Location = new System.Drawing.Point(426, 456);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(43, 42);
            this.btn_O.TabIndex = 14;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_I
            // 
            this.btn_I.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_I.Location = new System.Drawing.Point(377, 456);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(43, 42);
            this.btn_I.TabIndex = 15;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_P
            // 
            this.btn_P.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_P.Location = new System.Drawing.Point(475, 456);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(43, 42);
            this.btn_P.TabIndex = 16;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_F
            // 
            this.btn_F.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_F.Location = new System.Drawing.Point(202, 504);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(43, 42);
            this.btn_F.TabIndex = 17;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_D
            // 
            this.btn_D.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_D.Location = new System.Drawing.Point(153, 504);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(43, 42);
            this.btn_D.TabIndex = 18;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_S
            // 
            this.btn_S.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_S.Location = new System.Drawing.Point(104, 504);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(43, 42);
            this.btn_S.TabIndex = 19;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Q.Location = new System.Drawing.Point(55, 504);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(43, 42);
            this.btn_Q.TabIndex = 20;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_U
            // 
            this.btn_U.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_U.Location = new System.Drawing.Point(328, 456);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(43, 42);
            this.btn_U.TabIndex = 21;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Y.Location = new System.Drawing.Point(279, 456);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(43, 42);
            this.btn_Y.TabIndex = 22;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_T
            // 
            this.btn_T.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_T.Location = new System.Drawing.Point(230, 456);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(43, 42);
            this.btn_T.TabIndex = 23;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_R
            // 
            this.btn_R.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_R.Location = new System.Drawing.Point(181, 456);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(43, 42);
            this.btn_R.TabIndex = 24;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_E
            // 
            this.btn_E.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_E.Location = new System.Drawing.Point(132, 456);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(43, 42);
            this.btn_E.TabIndex = 25;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Z.Location = new System.Drawing.Point(83, 456);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(43, 42);
            this.btn_Z.TabIndex = 26;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_N
            // 
            this.btn_N.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_N.Location = new System.Drawing.Point(316, 552);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(43, 42);
            this.btn_N.TabIndex = 27;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_B
            // 
            this.btn_B.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_B.Location = new System.Drawing.Point(267, 552);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(43, 42);
            this.btn_B.TabIndex = 28;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_V
            // 
            this.btn_V.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_V.Location = new System.Drawing.Point(218, 552);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(43, 42);
            this.btn_V.TabIndex = 29;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_C
            // 
            this.btn_C.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_C.Location = new System.Drawing.Point(169, 552);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(43, 42);
            this.btn_C.TabIndex = 30;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_X
            // 
            this.btn_X.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_X.Location = new System.Drawing.Point(120, 552);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(43, 42);
            this.btn_X.TabIndex = 31;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_W
            // 
            this.btn_W.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_W.Location = new System.Drawing.Point(71, 552);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(43, 42);
            this.btn_W.TabIndex = 32;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_M
            // 
            this.btn_M.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_M.Location = new System.Drawing.Point(496, 504);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(43, 42);
            this.btn_M.TabIndex = 33;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_L
            // 
            this.btn_L.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_L.Location = new System.Drawing.Point(447, 504);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(43, 42);
            this.btn_L.TabIndex = 34;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_K
            // 
            this.btn_K.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_K.Location = new System.Drawing.Point(398, 504);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(43, 42);
            this.btn_K.TabIndex = 35;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_J
            // 
            this.btn_J.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_J.Location = new System.Drawing.Point(349, 504);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(43, 42);
            this.btn_J.TabIndex = 36;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_Valider_Motdepasse
            // 
            this.btn_Valider_Motdepasse.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Valider_Motdepasse.Location = new System.Drawing.Point(365, 552);
            this.btn_Valider_Motdepasse.Name = "btn_Valider_Motdepasse";
            this.btn_Valider_Motdepasse.Size = new System.Drawing.Size(189, 42);
            this.btn_Valider_Motdepasse.TabIndex = 37;
            this.btn_Valider_Motdepasse.Text = "Valider";
            this.btn_Valider_Motdepasse.UseVisualStyleBackColor = true;
            this.btn_Valider_Motdepasse.Click += new System.EventHandler(this.btn_Valider_Motdepasse_Click);
            // 
            // btn_DEL
            // 
            this.btn_DEL.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_DEL.Location = new System.Drawing.Point(524, 456);
            this.btn_DEL.Name = "btn_DEL";
            this.btn_DEL.Size = new System.Drawing.Size(94, 42);
            this.btn_DEL.TabIndex = 38;
            this.btn_DEL.Text = "DEL";
            this.btn_DEL.UseVisualStyleBackColor = true;
            this.btn_DEL.Click += new System.EventHandler(this.btn_DEL_Click);
            // 
            // btn_Accueil
            // 
            this.btn_Accueil.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Accueil.ForeColor = System.Drawing.Color.Navy;
            this.btn_Accueil.Location = new System.Drawing.Point(546, 624);
            this.btn_Accueil.Name = "btn_Accueil";
            this.btn_Accueil.Size = new System.Drawing.Size(94, 29);
            this.btn_Accueil.TabIndex = 39;
            this.btn_Accueil.Text = "Accueil";
            this.btn_Accueil.UseVisualStyleBackColor = true;
            this.btn_Accueil.Click += new System.EventHandler(this.btn_Accueil_Click);
            // 
            // tb_Motdepasse
            // 
            this.tb_Motdepasse.BackColor = System.Drawing.SystemColors.InfoText;
            this.tb_Motdepasse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_Motdepasse.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tb_Motdepasse.ForeColor = System.Drawing.Color.DodgerBlue;
            this.tb_Motdepasse.Location = new System.Drawing.Point(211, 409);
            this.tb_Motdepasse.Name = "tb_Motdepasse";
            this.tb_Motdepasse.Size = new System.Drawing.Size(198, 34);
            this.tb_Motdepasse.TabIndex = 40;
            this.tb_Motdepasse.TextChanged += new System.EventHandler(this.tb_Motdepasse_TextChanged);
            // 
            // tb_Digicode
            // 
            this.tb_Digicode.BackColor = System.Drawing.SystemColors.InfoText;
            this.tb_Digicode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_Digicode.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tb_Digicode.ForeColor = System.Drawing.Color.DodgerBlue;
            this.tb_Digicode.Location = new System.Drawing.Point(211, 45);
            this.tb_Digicode.Name = "tb_Digicode";
            this.tb_Digicode.Size = new System.Drawing.Size(198, 34);
            this.tb_Digicode.TabIndex = 41;
            // 
            // tb_texte
            // 
            this.tb_texte.BackColor = System.Drawing.SystemColors.InfoText;
            this.tb_texte.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_texte.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_texte.ForeColor = System.Drawing.Color.DodgerBlue;
            this.tb_texte.Location = new System.Drawing.Point(34, 346);
            this.tb_texte.Name = "tb_texte";
            this.tb_texte.Size = new System.Drawing.Size(584, 27);
            this.tb_texte.TabIndex = 42;
            // 
            // btn_Quitter
            // 
            this.btn_Quitter.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Quitter.ForeColor = System.Drawing.Color.Red;
            this.btn_Quitter.Location = new System.Drawing.Point(546, 12);
            this.btn_Quitter.Name = "btn_Quitter";
            this.btn_Quitter.Size = new System.Drawing.Size(94, 29);
            this.btn_Quitter.TabIndex = 43;
            this.btn_Quitter.Text = "Quitter";
            this.btn_Quitter.UseVisualStyleBackColor = true;
            this.btn_Quitter.Click += new System.EventHandler(this.btn_Quitter_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Reset.ForeColor = System.Drawing.Color.ForestGreen;
            this.btn_Reset.Location = new System.Drawing.Point(546, 57);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(94, 29);
            this.btn_Reset.TabIndex = 44;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // Bâtiment_Informatique
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WinFormsAP_Digicod.Properties.Resources.fond;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(652, 665);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_Quitter);
            this.Controls.Add(this.tb_texte);
            this.Controls.Add(this.tb_Digicode);
            this.Controls.Add(this.tb_Motdepasse);
            this.Controls.Add(this.btn_Accueil);
            this.Controls.Add(this.btn_DEL);
            this.Controls.Add(this.btn_Valider_Motdepasse);
            this.Controls.Add(this.btn_J);
            this.Controls.Add(this.btn_K);
            this.Controls.Add(this.btn_L);
            this.Controls.Add(this.btn_M);
            this.Controls.Add(this.btn_W);
            this.Controls.Add(this.btn_X);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_V);
            this.Controls.Add(this.btn_B);
            this.Controls.Add(this.btn_N);
            this.Controls.Add(this.btn_Z);
            this.Controls.Add(this.btn_E);
            this.Controls.Add(this.btn_R);
            this.Controls.Add(this.btn_T);
            this.Controls.Add(this.btn_Y);
            this.Controls.Add(this.btn_U);
            this.Controls.Add(this.btn_Q);
            this.Controls.Add(this.btn_S);
            this.Controls.Add(this.btn_D);
            this.Controls.Add(this.btn_F);
            this.Controls.Add(this.btn_P);
            this.Controls.Add(this.btn_I);
            this.Controls.Add(this.btn_O);
            this.Controls.Add(this.btn_G);
            this.Controls.Add(this.btn_H);
            this.Controls.Add(this.btn_A);
            this.Controls.Add(this.btn_Valider_Digicode);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_1);
            this.Name = "Bâtiment_Informatique";
            this.Text = "Bâtiment informatique";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_Valider_Digicode;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_Valider_Motdepasse;
        private System.Windows.Forms.Button btn_DEL;
        private System.Windows.Forms.Button btn_Accueil;
        private System.Windows.Forms.TextBox tb_Motdepasse;
        private System.Windows.Forms.TextBox tb_Digicode;
        private System.Windows.Forms.TextBox tb_texte;
        private System.Windows.Forms.Button btn_Quitter;
        private System.Windows.Forms.Button btn_Reset;
    }
}

