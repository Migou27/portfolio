﻿using System;
using System.IO; //Bibliothèque des commandes StreamReader
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace WinFormsAP_Digicod
{
    public partial class Bâtiment_Informatique : Form
    {
        //Initialisation des variables
        string digicode = "";
        string motdepasse = "";
        int index_digicode = 0;
        int erreur_motdepasse = 0;
        bool allow = true;
        bool verif_digicode = false;
        bool verif_motdepasse = false;
        System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"../../../among-us-failed-card-swipe-sound.wav");
        System.Media.SoundPlayer completed = new System.Media.SoundPlayer(@"../../../among-us-task-complete-sound-effect.wav");

        public Bâtiment_Informatique()
        {
            InitializeComponent();
            //Paramètres divers
            tb_Digicode.TextAlign = HorizontalAlignment.Center;
            tb_Motdepasse.TextAlign = HorizontalAlignment.Center;
            tb_texte.TextAlign = HorizontalAlignment.Center;
            tb_Digicode.ReadOnly = true;
            tb_Motdepasse.ReadOnly = true;
            tb_texte.ReadOnly = true;
            reset();
        }


        private void btn_Quitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void reset()
        {
            //Fonction de réinitialisation de la form (utilisé au lancement de celle-ci et lors du clic du bouton reset)
            reset_digicode2();
            reset_motdepasse();
            digicode_enable_true();
            cacher_clavier();
            tb_Digicode.Text = "";
            tb_Motdepasse.Text = "";
            tb_texte.Text = "";
            index_digicode = 0;
            erreur_motdepasse = 0;
            verif_motdepasse = false;
            verif_digicode = false;
        }

        private void reset_digicode()
        {
            //Fonction de reset du digicode (s'active si on appuie sur 5 boutons)
            if (index_digicode == 4)
            {
                digicode = "";
                index_digicode = 0;
                tb_Digicode.Text = "";
                verif_digicode = false;
                allow = true;
            }
        }

        private void reset_digicode2()
        {
            //Reset le digicode quoi qu'il arrive (utilisé après la validaton)
            digicode = "";
            index_digicode = 0;
            tb_Digicode.Text = "";
            allow = true;
        }

        private void reset_motdepasse()
        {
            //Réinitialisation du mot de passe après validtion
            tb_Motdepasse.Text = "";
            motdepasse = "";
            verif_motdepasse = false;
        }

        private void digicode_enable_false()
        {
            //Rend le digicode inaccessible
            btn_0.Enabled = false;
            btn_1.Enabled = false;
            btn_2.Enabled = false;
            btn_3.Enabled = false;
            btn_4.Enabled = false;
            btn_5.Enabled = false;
            btn_6.Enabled = false;
            btn_7.Enabled = false;
            btn_8.Enabled = false;
            btn_9.Enabled = false;
            btn_Valider_Digicode.Enabled = false;
            tb_Digicode.Enabled = false;
        }

        private void digicode_enable_true()
        {
            //Rend le digicode accessible
            btn_0.Enabled = true;
            btn_1.Enabled = true;
            btn_2.Enabled = true;
            btn_3.Enabled = true;
            btn_4.Enabled = true;
            btn_5.Enabled = true;
            btn_6.Enabled = true;
            btn_7.Enabled = true;
            btn_8.Enabled = true;
            btn_9.Enabled = true;
            btn_Valider_Digicode.Enabled = true;
            tb_Digicode.Enabled = true;
        }

        private void cacher_clavier()
        {
            //Cacher les boutons du clavier et les rendre inopérants
            btn_A.Enabled = false;
            btn_A.Visible = false;
            btn_B.Enabled = false;
            btn_B.Visible = false;
            btn_C.Enabled = false;
            btn_C.Visible = false;
            btn_D.Enabled = false;
            btn_D.Visible = false;
            btn_E.Enabled = false;
            btn_E.Visible = false;
            btn_F.Enabled = false;
            btn_F.Visible = false;
            btn_G.Enabled = false;
            btn_G.Visible = false;
            btn_H.Enabled = false;
            btn_H.Visible = false;
            btn_I.Enabled = false;
            btn_I.Visible = false;
            btn_J.Enabled = false;
            btn_J.Visible = false;
            btn_K.Enabled = false;
            btn_K.Visible = false;
            btn_L.Enabled = false;
            btn_L.Visible = false;
            btn_M.Enabled = false;
            btn_M.Visible = false;
            btn_N.Enabled = false;
            btn_N.Visible = false;
            btn_O.Enabled = false;
            btn_O.Visible = false;
            btn_P.Enabled = false;
            btn_P.Visible = false;
            btn_Q.Enabled = false;
            btn_Q.Visible = false;
            btn_R.Enabled = false;
            btn_R.Visible = false;
            btn_S.Enabled = false;
            btn_S.Visible = false;
            btn_T.Enabled = false;
            btn_T.Visible = false;
            btn_U.Enabled = false;
            btn_U.Visible = false;
            btn_V.Enabled = false;
            btn_V.Visible = false;
            btn_W.Enabled = false;
            btn_W.Visible = false;
            btn_X.Enabled = false;
            btn_X.Visible = false;
            btn_Y.Enabled = false;
            btn_Y.Visible = false;
            btn_Z.Enabled = false;
            btn_Z.Visible = false;
            btn_DEL.Enabled = false;
            btn_DEL.Visible = false;
            btn_Valider_Motdepasse.Enabled = false;
            btn_Valider_Motdepasse.Visible = false;
            tb_Motdepasse.Enabled = false;
            tb_Motdepasse.Visible = false;
        }

        private void montrer_clavier()
        {
            //Dévoiler les boutons du clavier et les rendre opérants
            btn_A.Enabled = true;
            btn_A.Visible = true;
            btn_B.Enabled = true;
            btn_B.Visible = true;
            btn_C.Enabled = true;
            btn_C.Visible = true;
            btn_D.Enabled = true;
            btn_D.Visible = true;
            btn_E.Enabled = true;
            btn_E.Visible = true;
            btn_F.Enabled = true;
            btn_F.Visible = true;
            btn_G.Enabled = true;
            btn_G.Visible = true;
            btn_H.Enabled = true;
            btn_H.Visible = true;
            btn_I.Enabled = true;
            btn_I.Visible = true;
            btn_J.Enabled = true;
            btn_J.Visible = true;
            btn_K.Enabled = true;
            btn_K.Visible = true;
            btn_L.Enabled = true;
            btn_L.Visible = true;
            btn_M.Enabled = true;
            btn_M.Visible = true;
            btn_N.Enabled = true;
            btn_N.Visible = true;
            btn_O.Enabled = true;
            btn_O.Visible = true;
            btn_P.Enabled = true;
            btn_P.Visible = true;
            btn_Q.Enabled = true;
            btn_Q.Visible = true;
            btn_R.Enabled = true;
            btn_R.Visible = true;
            btn_S.Enabled = true;
            btn_S.Visible = true;
            btn_T.Enabled = true;
            btn_T.Visible = true;
            btn_U.Enabled = true;
            btn_U.Visible = true;
            btn_V.Enabled = true;
            btn_V.Visible = true;
            btn_W.Enabled = true;
            btn_W.Visible = true;
            btn_X.Enabled = true;
            btn_X.Visible = true;
            btn_Y.Enabled = true;
            btn_Y.Visible = true;
            btn_Z.Enabled = true;
            btn_Z.Visible = true;
            btn_DEL.Enabled = true;
            btn_DEL.Visible = true;
            btn_Valider_Motdepasse.Visible = true;
            tb_Motdepasse.Enabled = true;
            tb_Motdepasse.Visible = true;
        }

        private void btn_Accueil_Click(object sender, EventArgs e)
        {
            //Retour à la fonction d'accueil
            Accueil m = new Accueil();
            m.Show();
            this.Hide();
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "0";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            //Test si le digicode contient déja 4 chiffres
            reset_digicode();
            //Ajoute 1 au digicode
            digicode = digicode + "1";
            index_digicode++;
            //Affichage du nombre de chiffres entrés
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        //Idem que pour le 1 etc...
        private void btn_2_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "2";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "3";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "4";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "5";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "6";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "7";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "8";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            reset_digicode();
            digicode = digicode + "9";
            index_digicode++;
            tb_Digicode.Text = tb_Digicode.Text + "* ";
        }

        private void btn_Valider_Digicode_Click_1(object sender, EventArgs e)
        {
            //Vérification qu'au moins un numéro a été entré
            if (index_digicode != 0)
            {
                //Vérification si il y a au moins 4 numéros
                if (index_digicode < 4)
                {
                    player.Play();
                    tb_texte.Text = "Code éronné !";
                    reset_digicode2();
                }
                else
                {
                    //Récupération des matricules
                    var reader = new StreamReader(File.OpenRead(@"../../../digicod_perso.csv"));
                    List<string> matricules = new List<string>();
                    List<string> autorisation = new List<string>();
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(';');

                        matricules.Add(values[0]);
                        autorisation.Add(values[3]);
                    }
                    reader.Close();
                    //
                    for (int i = 0; i < matricules.Count; i++)
                    {
                        //Comparaison de l'entrée utilisateur avec les matricules existants
                        if (digicode == matricules[i] && verif_digicode == false)
                        {
                            //Vérification de l'autorisation
                            if (autorisation[i] == "I" || autorisation[i] == "T")
                            {
                                tb_texte.Text = "Code bon ! Veuillez saisir votre mot de passe !";
                                montrer_clavier();
                                digicode_enable_false();
                                verif_digicode = true;
                                allow = true;
                            }
                            else
                            {
                                allow = false;
                            }
                        }
                    }
                    if (verif_digicode == false && allow == true)
                    {
                        player.Play();
                        tb_texte.Text = "Code éronné !";
                        reset_digicode();
                    }
                    else if (allow == false)
                    {
                        tb_texte.Text = "Vous n'avez pas accès à cette zone !";
                        player.Play();
                        reset_digicode();
                    }
                }
            }
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            //Ajoute A au mot de passe
            motdepasse = motdepasse + "A";
            //Affichage du nombre du lettres entrés 
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        //Idem que pour le A
        private void btn_B_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "B";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "C";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "D";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "E";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "F";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "G";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "H";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "I";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "J";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "K";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "L";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "M";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "N";

            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "O";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "P";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Q";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "R";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "S";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "T";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "U";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "V";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "W";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "X";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Y";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Z";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_DEL_Click(object sender, EventArgs e)
        {
            //Suppression du dernier caractère si il y en a au moins 1
            if (motdepasse != "")
            {
                tb_Motdepasse.Text = tb_Motdepasse.Text.Substring(0, tb_Motdepasse.Text.Length - 1);
                motdepasse = motdepasse.Substring(0, motdepasse.Length - 1);
            }
        }

        private void btn_Valider_Motdepasse_Click(object sender, EventArgs e)
        {
            //Récupération des mot de passe
            var reader = new StreamReader(File.OpenRead(@"../../../digicod_secure.csv"));
            List<string> mdp = new List<string>();
            List<string> autorisation = new List<string>();
            List<string> date_debut = new List<string>();
            List<string> date_fin = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');

                autorisation.Add(values[0]);
                date_debut.Add(values[1]);
                date_fin.Add(values[2]);
                mdp.Add(values[3]);
            }
            reader.Close();
            //Comparaison de l'entrée utilisateur avec les mot de passe existant
            for (int i = 0; i < mdp.Count; i++)
            {
                if (motdepasse == mdp[i] && verif_motdepasse == false && autorisation[i] != "E" && verif_date(date_debut[i], date_fin[i], date_du_jour()) == true)
                {
                    completed.Play();
                    tb_texte.Text = "Mot de passe correct ! Vous pouvez entrer !";
                    verif_motdepasse = true;
                    erreur_motdepasse = 0;
                }
            }
            if (verif_motdepasse == false)
            {
                player.Play();
                tb_texte.Text = "Mot de passe incorrect !";
                erreur_motdepasse++;
            }
            if (erreur_motdepasse == 3)
            {
                tb_texte.Text = "3 erreurs enregistrées !";
                String ligne_erreur = digicode + ";" + date_du_jour() + ";" + Heure() + ";" + "I" + "\n";
                File.AppendAllText(@"../../../digicod_erreur.csv", ligne_erreur);
                erreur_motdepasse = 0;
            }
            reset_motdepasse();
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            //Réinitialisation de la form
            reset();
        }

        private bool verif_date(string deb, string fin, string date)
        {
            if (int.Parse(deb.Substring(6, 4)) <= int.Parse(date.Substring(6, 4)) && int.Parse(fin.Substring(6, 4)) >= int.Parse(date.Substring(6, 4)))
            {
                if (int.Parse(deb.Substring(3, 2)) <= int.Parse(date.Substring(3, 2)) && int.Parse(fin.Substring(3, 2)) >= int.Parse(date.Substring(3, 2)))
                {
                    if (int.Parse(deb.Substring(0, 2)) <= int.Parse(date.Substring(0, 2)) && int.Parse(fin.Substring(0, 2)) >= int.Parse(date.Substring(0, 2)))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private string date_du_jour()
        {
            DateTime Jour = DateTime.Today;
            return Jour.ToString("d");
        }

        private string Heure()
        {
            DateTime heure = DateTime.Now;
            return heure.ToString("g").Substring(11, 5);
        }

        private void tb_Motdepasse_TextChanged(object sender, EventArgs e)
        {
            if(tb_Motdepasse.Text.Length == 6)
            {
                btn_Valider_Motdepasse.Enabled = true;
            }
            else
            {
                btn_Valider_Motdepasse.Enabled = false;
            }
        }

    }
}
