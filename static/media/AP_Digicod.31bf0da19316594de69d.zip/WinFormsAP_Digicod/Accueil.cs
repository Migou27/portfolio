﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsAP_Digicod
{
    public partial class Accueil : Form
    {
        public Accueil()
        {
            InitializeComponent();
        }

        private void btn_Interface_Info_Click(object sender, EventArgs e)
        {
            Bâtiment_Informatique m = new Bâtiment_Informatique();
            m.Show();
            this.Hide();
        }

        private void btn_Interface_Maison_Click(object sender, EventArgs e)
        {
            Maison_Des_Ligues m = new Maison_Des_Ligues();
            m.Show();
            this.Hide();
        }

        private void btn_Interface_Erreur_Click(object sender, EventArgs e)
        {
            Erreurs m = new Erreurs();
            m.Show();
            this.Hide();
        }
    }
}
