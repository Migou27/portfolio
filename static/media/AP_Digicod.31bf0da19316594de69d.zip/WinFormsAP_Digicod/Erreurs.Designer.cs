﻿
namespace WinFormsAP_Digicod
{
    partial class Erreurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Accueil = new System.Windows.Forms.Button();
            this.btn_Quitter = new System.Windows.Forms.Button();
            this.lv_listErreur = new System.Windows.Forms.ListView();
            this.Matricules = new System.Windows.Forms.ColumnHeader();
            this.Date = new System.Windows.Forms.ColumnHeader();
            this.Heure = new System.Windows.Forms.ColumnHeader();
            this.Porte = new System.Windows.Forms.ColumnHeader();
            this.btn_Afficher = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Accueil
            // 
            this.btn_Accueil.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Accueil.ForeColor = System.Drawing.Color.Navy;
            this.btn_Accueil.Location = new System.Drawing.Point(694, 524);
            this.btn_Accueil.Name = "btn_Accueil";
            this.btn_Accueil.Size = new System.Drawing.Size(94, 29);
            this.btn_Accueil.TabIndex = 0;
            this.btn_Accueil.Text = "Accueil";
            this.btn_Accueil.UseVisualStyleBackColor = true;
            this.btn_Accueil.Click += new System.EventHandler(this.btn_Accueil_Click);
            // 
            // btn_Quitter
            // 
            this.btn_Quitter.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Quitter.ForeColor = System.Drawing.Color.Red;
            this.btn_Quitter.Location = new System.Drawing.Point(694, 12);
            this.btn_Quitter.Name = "btn_Quitter";
            this.btn_Quitter.Size = new System.Drawing.Size(94, 29);
            this.btn_Quitter.TabIndex = 45;
            this.btn_Quitter.Text = "Quitter";
            this.btn_Quitter.UseVisualStyleBackColor = true;
            this.btn_Quitter.Click += new System.EventHandler(this.btn_Quitter_Click);
            // 
            // lv_listErreur
            // 
            this.lv_listErreur.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Matricules,
            this.Date,
            this.Heure,
            this.Porte});
            this.lv_listErreur.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_listErreur.HideSelection = false;
            this.lv_listErreur.Location = new System.Drawing.Point(198, 118);
            this.lv_listErreur.Name = "lv_listErreur";
            this.lv_listErreur.Size = new System.Drawing.Size(398, 339);
            this.lv_listErreur.TabIndex = 47;
            this.lv_listErreur.UseCompatibleStateImageBehavior = false;
            this.lv_listErreur.View = System.Windows.Forms.View.Details;
            // 
            // Matricules
            // 
            this.Matricules.Text = "Matricules";
            this.Matricules.Width = 100;
            // 
            // Date
            // 
            this.Date.Text = "Date";
            this.Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Date.Width = 100;
            // 
            // Heure
            // 
            this.Heure.Text = "Heure";
            this.Heure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Heure.Width = 100;
            // 
            // Porte
            // 
            this.Porte.Text = "Porte";
            this.Porte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Porte.Width = 100;
            // 
            // btn_Afficher
            // 
            this.btn_Afficher.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Afficher.FlatAppearance.BorderSize = 0;
            this.btn_Afficher.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Afficher.Location = new System.Drawing.Point(12, 12);
            this.btn_Afficher.Name = "btn_Afficher";
            this.btn_Afficher.Size = new System.Drawing.Size(187, 74);
            this.btn_Afficher.TabIndex = 48;
            this.btn_Afficher.Text = "Afficher la liste des erreurs";
            this.btn_Afficher.UseVisualStyleBackColor = true;
            this.btn_Afficher.Click += new System.EventHandler(this.btn_Afficher_Click);
            // 
            // Erreurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WinFormsAP_Digicod.Properties.Resources.fond;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 565);
            this.Controls.Add(this.btn_Afficher);
            this.Controls.Add(this.lv_listErreur);
            this.Controls.Add(this.btn_Quitter);
            this.Controls.Add(this.btn_Accueil);
            this.Name = "Erreurs";
            this.Text = "Erreurs";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Accueil;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Button btn_Quitter;
        private System.Windows.Forms.ListView lv_listErreur;
        private System.Windows.Forms.Button btn_Afficher;
        private System.Windows.Forms.ColumnHeader Matricules;
        private System.Windows.Forms.ColumnHeader Date;
        private System.Windows.Forms.ColumnHeader Heure;
        private System.Windows.Forms.ColumnHeader Porte;
    }
}