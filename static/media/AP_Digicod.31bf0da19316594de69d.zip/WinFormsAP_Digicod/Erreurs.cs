﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsAP_Digicod
{
    public partial class Erreurs : Form
    {
        public Erreurs()
        {
            InitializeComponent();
            lv_listErreur.Visible = false;
        }

        private void btn_Accueil_Click(object sender, EventArgs e)
        {
            Accueil m = new Accueil();
            m.Show();
            this.Hide();
        }

        private void btn_Quitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Afficher_Click(object sender, EventArgs e)
        {
            lv_listErreur.Items.Clear();
            lv_listErreur.Visible = true;
            var reader = new StreamReader(File.OpenRead(@"../../../digicod_erreur.csv"));
            List<string> matricules = new List<string>();
            List<string> date = new List<string>();
            List<string> heure = new List<string>();
            List<string> porte = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');

                matricules.Add(values[0]);
                date.Add(values[1]);
                heure.Add(values[2]);
                porte.Add(values[3]);
            }
            reader.Close();
            for (int i = 1; i < porte.Count; i++)
            {

                ListViewItem ligne = new ListViewItem();

                ligne.Text = matricules[i];
                ligne.SubItems.Add(date[i]);
                ligne.SubItems.Add(heure[i]);
                ligne.SubItems.Add(porte[i]);

                lv_listErreur.Items.Add(ligne);
            }
        }
    }
}
