﻿
namespace WinFormsAP_Digicod
{
    partial class Accueil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Interface_Info = new System.Windows.Forms.Button();
            this.btn_Interface_Maison = new System.Windows.Forms.Button();
            this.btn_Interface_Erreur = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Interface_Info
            // 
            this.btn_Interface_Info.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Interface_Info.Location = new System.Drawing.Point(87, 150);
            this.btn_Interface_Info.Name = "btn_Interface_Info";
            this.btn_Interface_Info.Size = new System.Drawing.Size(456, 56);
            this.btn_Interface_Info.TabIndex = 0;
            this.btn_Interface_Info.Text = "Interface bâtiment informatique";
            this.btn_Interface_Info.UseVisualStyleBackColor = true;
            this.btn_Interface_Info.Click += new System.EventHandler(this.btn_Interface_Info_Click);
            // 
            // btn_Interface_Maison
            // 
            this.btn_Interface_Maison.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Interface_Maison.Location = new System.Drawing.Point(87, 56);
            this.btn_Interface_Maison.Name = "btn_Interface_Maison";
            this.btn_Interface_Maison.Size = new System.Drawing.Size(456, 53);
            this.btn_Interface_Maison.TabIndex = 1;
            this.btn_Interface_Maison.Text = "Interface bâtiment de la maison des Ligues";
            this.btn_Interface_Maison.UseVisualStyleBackColor = true;
            this.btn_Interface_Maison.Click += new System.EventHandler(this.btn_Interface_Maison_Click);
            // 
            // btn_Interface_Erreur
            // 
            this.btn_Interface_Erreur.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Interface_Erreur.Location = new System.Drawing.Point(87, 246);
            this.btn_Interface_Erreur.Name = "btn_Interface_Erreur";
            this.btn_Interface_Erreur.Size = new System.Drawing.Size(456, 53);
            this.btn_Interface_Erreur.TabIndex = 2;
            this.btn_Interface_Erreur.Text = "Interface des erreurs";
            this.btn_Interface_Erreur.UseVisualStyleBackColor = true;
            this.btn_Interface_Erreur.Click += new System.EventHandler(this.btn_Interface_Erreur_Click);
            // 
            // Accueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WinFormsAP_Digicod.Properties.Resources.fond;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(634, 369);
            this.Controls.Add(this.btn_Interface_Erreur);
            this.Controls.Add(this.btn_Interface_Maison);
            this.Controls.Add(this.btn_Interface_Info);
            this.Name = "Accueil";
            this.Text = "Accueil";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Interface_Info;
        private System.Windows.Forms.Button btn_Interface_Maison;
        private System.Windows.Forms.Button btn_Interface_Erreur;
    }
}