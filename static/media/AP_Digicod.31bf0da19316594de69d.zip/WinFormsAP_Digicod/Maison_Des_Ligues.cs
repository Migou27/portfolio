﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsAP_Digicod
{
    public partial class Maison_Des_Ligues : Form
    {
        string motdepasse = "";
        int erreur_motdepasse = 0;
        bool verif_motdepasse = false;
        System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"../../../among-us-failed-card-swipe-sound.wav");
        System.Media.SoundPlayer completed = new System.Media.SoundPlayer(@"../../../among-us-task-complete-sound-effect.wav");

        public Maison_Des_Ligues()
        {
            InitializeComponent();
            tb_Motdepasse.ReadOnly = true;
            tb_texte.ReadOnly = true;
            tb_Motdepasse.TextAlign = HorizontalAlignment.Center;
            tb_texte.TextAlign = HorizontalAlignment.Center;
            btn_Valider_Motdepasse.Enabled = false;
            reset();
        }

        private void btn_Accuiel_Click(object sender, EventArgs e)
        {
            Accueil m = new Accueil();
            m.Show();
            this.Hide();
        }

        private void reset_motdepasse()
        {
            //Réinitialisation du mot de passe après validtion
            tb_Motdepasse.Text = "";
            motdepasse = "";
            verif_motdepasse = false;
        }

        private bool verif_date(string deb, string fin, string date)
        {
            if (int.Parse(deb.Substring(6, 4)) <= int.Parse(date.Substring(6, 4)) && int.Parse(fin.Substring(6, 4)) >= int.Parse(date.Substring(6, 4)))
            {
                if (int.Parse(deb.Substring(3, 2)) <= int.Parse(date.Substring(3, 2)) && int.Parse(fin.Substring(3, 2)) >= int.Parse(date.Substring(3, 2)))
                {
                    if (int.Parse(deb.Substring(0, 2)) <= int.Parse(date.Substring(0, 2)) && int.Parse(fin.Substring(0, 2)) >= int.Parse(date.Substring(0, 2)))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private string date_du_jour()
        {
            DateTime Jour = DateTime.Today;
            return Jour.ToString("d");
        }

        private string Heure()
        {
            DateTime heure = DateTime.Now;
            return heure.ToString("g").Substring(11, 5);
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "A";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "B";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "C";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "D";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "E";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "F";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "G";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "H";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "I";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "J";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "K";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "L";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "M";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "N";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "O";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "P";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Q";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "R";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "S";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "T";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "U";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "V";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "W";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "X";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Y";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            motdepasse = motdepasse + "Z";
            tb_Motdepasse.Text = tb_Motdepasse.Text + "*";
        }

        private void btn_DEL_Click(object sender, EventArgs e)
        {
            //Suppression du dernier caractère si il y en a au moins 1
            if (motdepasse != "")
            {
                tb_Motdepasse.Text = tb_Motdepasse.Text.Substring(0, tb_Motdepasse.Text.Length - 1);
                motdepasse = motdepasse.Substring(0, motdepasse.Length - 1);
            }
        }

        private void btn_Valider_Motdepasse_Click(object sender, EventArgs e)
        {
            //Récupération des mot de passe
            var reader = new StreamReader(File.OpenRead(@"../../../digicod_secure.csv"));
            List<string> mdp = new List<string>();
            List<string> autorisation = new List<string>();
            List<string> date_debut = new List<string>();
            List<string> date_fin = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');

                autorisation.Add(values[0]);
                date_debut.Add(values[1]);
                date_fin.Add(values[2]);
                mdp.Add(values[3]);
            }
            reader.Close();
            //Comparaison de l'entrée utilisateur avec les mot de passe existant
            for (int i = 0; i < mdp.Count; i++)
            {
                if (motdepasse == mdp[i] && verif_motdepasse == false && autorisation[i] != "I" && verif_date(date_debut[i], date_fin[i], date_du_jour()) == true)
                {
                    completed.Play();
                    tb_texte.Text = "Mot de passe correct ! Vous pouvez entrer !";
                    verif_motdepasse = true;
                    erreur_motdepasse = 0;
                }
            }
            if (verif_motdepasse == false)
            {
                player.Play();
                tb_texte.Text = "Mot de passe incorrect !";
                erreur_motdepasse++;
            }
            //Ecriture en cas de 3 erreurs
            if (erreur_motdepasse == 3)
            {
                tb_texte.Text = "3 erreurs enregistrées !";
                String ligne_erreur = "" + ";" + date_du_jour() + ";" + Heure() + ";" + "E" + "\n";
                File.AppendAllText(@"../../../digicod_erreur.csv", ligne_erreur);
                erreur_motdepasse = 0;
            }
            reset_motdepasse();
        }

        private void tb_Motdepasse_TextChanged(object sender, EventArgs e)
        {
            if(tb_Motdepasse.Text.Length == 6)
            {
                btn_Valider_Motdepasse.Enabled = true;
            }
            else
            {
                btn_Valider_Motdepasse.Enabled = false;
            }
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void reset()
        {
            tb_Motdepasse.Text = "";
            tb_texte.Text = "";
            erreur_motdepasse = 0;
            verif_motdepasse = false;
            reset_motdepasse();
        }

        private void btn_Quitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
