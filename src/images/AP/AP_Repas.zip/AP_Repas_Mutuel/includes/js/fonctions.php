function open_file(nomFichier)
{
        window.open('nomFichier','Document','menubar=no, scrollbars=no, top=100, left=100, width=300, height=200');
}