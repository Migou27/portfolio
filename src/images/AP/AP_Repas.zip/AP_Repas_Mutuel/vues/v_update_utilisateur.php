<div class="home">
          
<div id="Home_title_ss">
              <br /><br />
              <?php
              echo '<div id="Titles">'.$_SESSION['ident']."</div>";
              echo '<br> ' ;
              echo 'Gestion des utilisateurs ' ;
              ?>
</div>

<?php

$idUser = $_POST["utilisateurs"];

if($_POST["rbtnGestion"] == 1){ // renvoie la page pour modifier un utilisateur
    echo 'MODIFICATION <br> <br>';

    $utilisateur = get1Utilisateur($idUser);

    echo ' '
    . '<form style="margin: auto; width: 220px;" method="POST" action="index.php?uc=gestion&action=utilisateur">'

    . 'Nom:<input type="text" class="input_text2" name="nomUpdate" value ="'.$utilisateur["nom"].'" size=30>&nbsp;&nbsp; '               // nom 
    . 'Prenom :<input type="text" class="input_text2" name="prenomUpdate" value ="'.$utilisateur["prenom"].'" size=30> '                 // prenom
    . 'id Classe :<input type="text" class="input_text2" name="idClasseUpdate" value ="'.$utilisateur["idClasse"].'" size=30> '          // id classe
    . 'Login :<input type="text" class="input_text2" name="loginUpdate" value ="'.$utilisateur["login"].'" size=30>'                     // login
    . 'Statut :<input type="text" class="input_text2" name="statutUpdate" value ="'.$utilisateur["statut"].'" size=30>'                  // statut
    . 'crédits repas :<input type="text" class="input_text2" name="creditRepasUpdate" value ="'.$utilisateur["creditRepas"].'" size=30>' // crédit
    . '<input id="idUpdate" name="idUpdate" type="hidden" value="'.$idUser.'">'
    . '<input type="submit" class="btn btn-info connectbt">'

    .'</form> ' ;
    
}


else if($_POST["rbtnGestion"] == 2){ // renvoie la page pour supprimer un utilisateur
    deleteUtilisateur($idUser);
    header("Location: index.php?uc=gestion&action=utilisateur");
    die();      
}


else if($_POST["rbtnGestion"] == 3){ // renvoie la page pour ajouter un utilisateur
    echo 'AJOUT';

    echo ' '
    . '<form style="margin: auto; width: 220px;" method="POST" action="index.php?uc=gestion&action=utilisateur">'

    . 'Nom:<input type="text" class="input_text2" name="nomCreate" placeholder="Nom" size=30>&nbsp;&nbsp; '                   // nom 
    . 'Prenom :<input type="text" class="input_text2" name="prenomCreate" placeholder="Prénom" size=30> '                     // prenom
    . 'id Classe :<input type="text" class="input_text2" name="idClasseCreate" placeholder="2" size=30> '                     // id classe
    . 'Login :<input type="text" class="input_text2" name="loginCreate" placeholder="Login" size=30>'                         // login
    . 'mot de passe :<input type="password" class="input_text2" name="mdpCreate" placeholder="******" size=30>'                   // mdp
    . 'Statut :<input type="text" class="input_text2" name="statutCreate" placeholder="1" size=30>'                           // statut
    . 'crédits repas :<input type="text" class="input_text2" name="creditRepasCreate" placeholder="10" size=30>'              // crédit
    . '<input type="submit" class="btn btn-info connectbt">'

    .'</form> ' ;
}

?>


</div>