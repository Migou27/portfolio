      <div class="home">
          
          <div id="Home_title_ss">
              <br /><br />
            <?php
            echo '<div id="Titles">Utilisateur connecté : '.$_SESSION['ident']."</div><br />";
            echo  '<div id="Titles">Gestion des formules</div><br/>';
            ?>
            <table class="table table-stripped">
            <tr>
                <td colspan = 6><a href="index.php?uc=gestion&action=formuleAjouter">Ajouter une formule</a></td>
            </tr>
            <tr>
                <td>Formules</td>
                <td></td>
                <td>Tarifs</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <?php
            $numFormuleMenu = getFormulesUtilisees();
            foreach($lesFormules as $uneFormule){
                if (isset($_REQUEST['action']) && ($_REQUEST['action'] == 'formules') 
                && isset($_REQUEST['id']) && ($_REQUEST['id'] == $uneFormule['numFormule'])){
                    echo '<tr>'
                    . '<form action="index.php?uc=gestion&action=modifierformule&id='.$uneFormule['numFormule'].'" method="POST">'
                    . '<td> <input type ="text" name="modifierlibelle" value="'.$uneFormule['libelleFormule'].'"> </td>'
                    . '<td></td>'
                    . '<td> <input type ="text" name="modifiertarif" value="'.$uneFormule['tarifFormule'].'"> </td>'
                    . '<td></td>'
                    . '<td> <input type="submit" class="btn btn-info connectbt"value="Valider"></td>' 
                    . '<td> <button class="btn btn-info connectbt"><a href="index.php?uc=gestion&action=formules">Retour</a></button> </td>'
                    . '</form>';
                }else{
                    echo '<tr>'
                    . '<td>' . $uneFormule['libelleFormule'] . '</td>'
                    . '<td></td>'
                    . '<td>' . $uneFormule['tarifFormule'] . '</td>'
                    . '<td></td>'
                    . '<td> <button class="btn btn-info connectbt"><a href="index.php?uc=gestion&action=formules&id='.$uneFormule['numFormule'].'">Modifier</a></button> </td>' ;
                    $trouve = false;
                    foreach($numFormuleMenu as $unNum){
                        if($uneFormule['numFormule'] == $unNum['numFormuleMenu']){
                            $trouve = true;
                        }
                    }
                    if ($trouve == true){
                        echo '</tr></br>';
                    }else{
                        echo '<td> <button class="btn btn-info connectbt"><a href="index.php?uc=gestion&action=supprimerformule&id='.$uneFormule['numFormule'].'">Supprimer</a></button> </td>';
                    }
                    echo '</tr></br>' ;
                }
            }
            ?>
            </table>
          </div>

      </div>