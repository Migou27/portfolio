<div class="home">
          
          <div id="Home_title_ss">
              <br /><br />
              <?php
              if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'modifierformule'){
                $lesFormules = getLesFormules();
                $trouve = false;
                foreach($lesFormules as $uneFormule){
                    if($uneFormule['libelleFormule'] == $_POST['modifierlibelle']){
                        $trouve = true;
                    }
                }
                if($trouve == true){
                    echo 'La formule existe déjà !</br></br>';
                }else{
                    modifierFormule($_REQUEST['id'], $_POST['modifierlibelle'], $_POST['modifiertarif']);
                    echo 'La formule a bien été mofifiée !</br></br>' ;
                }
              }
              if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'supprimerformule'){
                  supprimerFormule($_REQUEST['id']);
                  echo 'La formule a bien été supprimée !</br></br>';
              }
              ?>
              <button class="btn btn-info connectbt"><a href="index.php?uc=gestion&action=formules">Retour</a></button>