<div class="home">
          
<div id="Home_title_ss">
              <br /><br />
              <?php
              echo '<div id="Titles">'.$_SESSION['ident']."</div>";
              echo '<br> ' ;
              echo 'Gestion des utilisateurs ' ;
              ?>
</div>
          
         
        <?php 

        if(isset($_POST["nomUpdate"])){
            updateUtilisateur($_POST["idUpdate"],$_POST["nomUpdate"],$_POST["prenomUpdate"],$_POST["idClasseUpdate"],$_POST["loginUpdate"],$_POST["statutUpdate"],$_POST["creditRepasUpdate"]);
        }
        else if(isset($_POST["nomCreate"])){
            createUtilisateur($_POST["nomCreate"],$_POST["prenomCreate"],$_POST["idClasseCreate"],$_POST["loginCreate"],sha1($_POST["mdpCreate"]),$_POST["statutCreate"],$_POST["creditRepasCreate"]);
        }

        $Utilisateurs = getUtilisateur();     
        echo '<br>
        <form name="gererLesUtilisateurs" method="POST" action="index.php?uc=gestion&action=utilisateurUpdate">
        <table>
            <select name="utilisateurs">';
            
            foreach($Utilisateurs as $unUtilisateur) {
            
                echo '<option value='.$unUtilisateur['id'].'>'. $unUtilisateur['nom'] ." ". $unUtilisateur['prenom'].'</option>';
            }
            echo '</select>'
            . '</table>';
          

        echo '

        <input type="radio" id="Modifier"
        name="rbtnGestion" value="1" checked>
        <label for="modifier">Modifier</label>

        <input type="radio" id="Supprimer"
        name="rbtnGestion" value="2">
        <label for="modifier">Supprimer</label>

        <input type="radio" id="Ajouter"
        name="rbtnGestion" value="3">
        <label for="modifier">Ajouter</label>

        <br>
        <input type="submit" class="btn btn-info connectbt">

        </form>';
        
        ?>
      </div>