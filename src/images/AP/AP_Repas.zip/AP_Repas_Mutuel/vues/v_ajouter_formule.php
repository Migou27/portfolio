<div class="home">
          
<div id="Home_title_ss">
              <br /><br />
              <?php
              echo '<div id="Titles">'.$_SESSION['ident']."</div>";
              echo '<br> ' ;
              echo 'Ajouter une formule ' ;
              ?>
</div>



<?php

    echo '<form method="POST" action="index.php?uc=gestion&action=formuleAjouter2">'
    . '<input type="text" class="input_text2" name="laFormule" placeholder="Formule" size=50>&nbsp;&nbsp;'
    . '<input type="text" class="input_text2" name="leTarif" placeholder="Tarif" size=10>&nbsp;&nbsp;'
    . '<br> <br>'
    . '<input type="submit" class="btn btn-info connectbt">'
    . '</form><br><br>';
    

?>
<button class="btn btn-info connectbt"><a href="index.php?uc=gestion&action=menu">Retour</a></button>     
         
        
        

     