<?php

namespace ContainerMTWLfo4;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHoldercd4ea = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerae260 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesd501b = [
        
    ];

    public function getConnection()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getConnection', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getMetadataFactory', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getExpressionBuilder', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'beginTransaction', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getCache', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getCache();
    }

    public function transactional($func)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'transactional', array('func' => $func), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'wrapInTransaction', array('func' => $func), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'commit', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->commit();
    }

    public function rollback()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'rollback', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getClassMetadata', array('className' => $className), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'createQuery', array('dql' => $dql), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'createNamedQuery', array('name' => $name), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'createQueryBuilder', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'flush', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'clear', array('entityName' => $entityName), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->clear($entityName);
    }

    public function close()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'close', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->close();
    }

    public function persist($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'persist', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'remove', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'refresh', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'detach', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'merge', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getRepository', array('entityName' => $entityName), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'contains', array('entity' => $entity), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getEventManager', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getConfiguration', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'isOpen', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getUnitOfWork', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getProxyFactory', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'initializeObject', array('obj' => $obj), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'getFilters', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'isFiltersStateClean', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'hasFilters', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return $this->valueHoldercd4ea->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerae260 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHoldercd4ea) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldercd4ea = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldercd4ea->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__get', ['name' => $name], $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        if (isset(self::$publicPropertiesd501b[$name])) {
            return $this->valueHoldercd4ea->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercd4ea;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldercd4ea;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercd4ea;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldercd4ea;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__isset', array('name' => $name), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercd4ea;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHoldercd4ea;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__unset', array('name' => $name), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercd4ea;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHoldercd4ea;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__clone', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        $this->valueHoldercd4ea = clone $this->valueHoldercd4ea;
    }

    public function __sleep()
    {
        $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, '__sleep', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;

        return array('valueHoldercd4ea');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerae260 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerae260;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerae260 && ($this->initializerae260->__invoke($valueHoldercd4ea, $this, 'initializeProxy', array(), $this->initializerae260) || 1) && $this->valueHoldercd4ea = $valueHoldercd4ea;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldercd4ea;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHoldercd4ea;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
