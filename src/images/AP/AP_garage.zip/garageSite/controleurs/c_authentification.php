<?php
if (!isset($_REQUEST['action']))
	$action = "afficher" ;
else
	$action = $_REQUEST['action'] ;
	
switch ($action)
{
	case "afficher" : { 
            $Login = $_POST['Login'] ;
            $Mdp = $_POST['Mdp'] ;
            $verif = verifierIdentification($Login, md5($Mdp)) ;
            if ($verif = true){
                header ("Location:index.php") ;
            }
            else{
                session_destroy();
                header ("Location:index.php?uc=accueil") ;
            }
            
            break ;   
    }
}
?>