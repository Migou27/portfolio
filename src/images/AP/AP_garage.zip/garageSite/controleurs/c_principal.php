<?php
if (!isset($_REQUEST['uc'])) {
    $uc = "accueil" ;
}
else {
    $uc = $_REQUEST['uc'] ;
}

switch ($uc)
{
    case 'accueil' : {  include "c_accueil.php" ; break ;} 

    case 'authentification' : {include "c_authentification.php" ; break;}

    case 'marque' : {include "c_marques.php" ; break;}

    case 'modele' : {include "c_modele.php" ; break;}
}

?>