<?php
if (!isset($_REQUEST['action']))
	$action = "afficher" ;
else
	$action = $_REQUEST['action'] ;


if (!isset($_REQUEST['id']))
	$id = 0 ;
else
	$id = $_REQUEST['id'] ;

	
switch ($action)
{
	case "afficher" : { 
                $lesMarques = getLesMarques() ;
                require "vues/v_marques_liste.php" ; 
                break ;
        }
        case "ajouter" : {
                require "vues/v_marques_ajouter.php" ;
                break ;
        }

        case "validajout" : {
                $marqueAjout = $_POST['marqueAjout'] ;
                if (verifierDonblons($marqueAjout) == false){
                        ajouterMarque($marqueAjout);
                        echo '<div class="home">'
                             . 'La marque ' . $marqueAjout . ' a bien été ajoutée' ;
                        echo '<br/><br/><a href="index.php?uc=marque">Retour</a> </div>' ;
                }else{
                        echo '<div class="home">'
                                        .'La marque ' . $marqueAjout . ' existe déjà !' ;
                        echo '<br/><br/><a href="index.php?uc=marque">Retour</a> </div>' ;
                }
                break;
        }

        case "modifier" : {
                $lesMarques = getLesMarques() ;
                require "vues/v_marques_liste.php" ;
                break;
        }

        case "validmodif" : {
                $marqueModif = $_POST['modifMarque'] ;
                if ($marqueModif == ""){
                        echo '<div class="home">'
                                . '<p class="error">Veuillez saisir une marque !</p>'
                                . '<a href="index.php?uc=marque">Retour</a>' ;

                }else{
                        if (verifierDonblons($marqueModif) == false){
                                modifierMarque($id, $marqueModif);
                                echo '<div class="home">'
                                        . 'La marque ' . $marqueModif . ' a bien été modifiée' ;
                                echo '<br/><br/><a href="index.php?uc=marque">Retour</a> </div>' ;
                        }else{
                                echo '<div class="home">'
                                        .'La marque ' . $marqueModif . ' existe déjà !' ;
                                echo '<br/><br/><a href="index.php?uc=marque">Retour</a> </div>' ;
                        }
                }
                break;
        }

        case "supprimer" : {
                supprVehicule($id);
                supprModele($id);
                supprMarque($id);
                echo 'La marque a bien été supprimée !';
                echo '<br/><br/>' ;
                echo '<button><a href="index.php?uc=marque&action=afficher">Retour</a></button>';
                break;
        }
}
?>
