<?php
if (!isset($_REQUEST['action']))
	$action = "afficher" ;
else
	$action = $_REQUEST['action'] ;
	
switch ($action)
{
	case "afficher" : {
            $lesModeles = getLesModeles();
            require "v_modele.php" ;
            break ;   
    }
}
?>