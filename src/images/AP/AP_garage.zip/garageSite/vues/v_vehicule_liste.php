<div class="home">
    <?php
        if (!isset($_SESSION['tl_droit'])){

            echo    '<form action="index.php?uc=authentification&action=afficher" method="post" class="formulaire">
                    <input type="text" name="Login" placeholder="Login">
                    <input type="password" name="Mdp" placeholder="Mot de Passe">
                    <button type="submit">Ok</button>
                    </form>' ;
        }
    ?>
    <div id="Home_title">Liste de tous les véhicules</div>
    <table class="table table-striped">   
        <tr>
            <th>N°</th>
            <th>Marque</th>
            <th>Modèle</th>  
            <th>Km</th>
            <th>Prix</th>
        </tr>
        <?php
        $cpt = 1;
        foreach ($lesVehicules as $leVehicule) {
            echo '<tr>'
            . '<td> <a href="index.php?uc=accueil&action=detail&id=' . $leVehicule['vh_id'] . '">' . $cpt . '</a> </td>'
            . '<td>' . $leVehicule['mq_libelle'] . '</td>'
            . '<td>' . $leVehicule['md_libelle'] . '</td>'
            . '<td>' . $leVehicule['vh_km'] . '</td>'
            . '<td>' . number_format($leVehicule['vh_prix'], 2, ',', ' ') . ' €</td>'
            . '</tr>';
            $cpt++;
        }
        ?>
    </table>
</div>