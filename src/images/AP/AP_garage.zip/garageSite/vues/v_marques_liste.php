<div id="Home_title"></div>
    <table class="table table-striped">
        <tr>
            <th colspan = 3>Gestion des marques de véhicules</th>
        </tr>
        <tr>
            <th colspan = 3>Ajouter une nouvelle marque : <a href="index.php?uc=marque&action=ajouter"><img src="includes/img/plus.png" alt="Logo plus" width="30px" height="30px" title="Ajouter"></a></th>        
        </tr>
        <tr>
            <td>Libelle</td>
            <td></td>
            <td></td>
        </tr>
        <?php
        foreach ($lesMarques as $laMarque) {
            if (isset($_REQUEST['action']) && ($_REQUEST['action'] == 'modifier') 
            && isset($_REQUEST['id']) && ($_REQUEST['id'] == $laMarque['mq_id'])){
                echo '<tr>'
                    . '<form action="index.php?uc=marque&action=validmodif&id='.$laMarque['mq_id'].'" method="POST">'
                    . ' <td> <input type ="text" name="modifMarque" placeholder="'.$laMarque['mq_libelle'].'"> </td>'
                    . ' <td> <button type="submit">Valider</button> </td>'
                    . ' <td> <button><a href="index.php?uc=marque&action=afficher">Retour</a></button> </td>'
                    . '</form>' ;                   
            }else{
                echo '<tr>'
                    . '<td>' . $laMarque['mq_libelle'] . '</td>'
                    . '<td> <button><a href="index.php?uc=marque&action=modifier&id='.$laMarque['mq_id'].'">Modifier</a></button> </td>'
                    . '<td> <button><a href="index.php?uc=marque&action=supprimer&id='.$laMarque['mq_id'].'">Supprimer</a></button> </td>'
                    . '</tr>' ;
            }
        }
        ?>
    </table>
</div>