<div id="Home_title">
    <form action="index.php?uc=marque&action=validajout" method="post" class="formulaire" onsubmit="javascript:return estValideMarque()">
    <p>Ajout d'une marque</p>
        <input type="text" name="marqueAjout" placeholder="Libellé de la marque">
        <button type="submit">Valider</button>
    </form>
    <img src="includes/img/amongus.gif" width="200px" height="175px" class="amongus">
    <img src="includes/img/mario.gif" width="200px" height="175px" class="mario">
    <img src="includes/img/hectorcopter.gif" width="200px" height="200px" class="hectorcopter">
</div>