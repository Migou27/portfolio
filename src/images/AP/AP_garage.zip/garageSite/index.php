<?php
session_start();
include "includes/header.php" ;
include "includes/modele/connexion.php" ;
include "includes/modele/gestion_bdd.php" ;
include "controleurs/c_principal.php" ;
include "includes/footer.php" ;
?>
