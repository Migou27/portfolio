function estValideMarque() {
    marque = document.forms[0].marqueAjout.value ;
    if (marque=='') {
        alert ("Le libelle de la marque est obligatoire") ;
        return false ;
    }
    else {
        return true ;
    }
}
