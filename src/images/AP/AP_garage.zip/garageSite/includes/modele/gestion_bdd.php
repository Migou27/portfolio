<?php
/**
 * Vérifie les identifiants de connexion et instancie les variables de session
 
 * @param $loginSaisi 
 * @param $mdpSaisi
 * @return un boolÃ©en true si utilisateur connu, false sinon 
*/
function verifierIdentification($loginSaisi,$mdpSaisi ) {
    require "connexion.php" ;
    $sql="select * from utilisateur" ;
    $exec=$bdd->query($sql);
    $trouve = false ;
    $fin=false ;
    while (!$trouve && !$fin)
    {
        if ($ligne = $exec->fetch())
        {
            if ($ligne['tl_login']==$loginSaisi && $ligne['tl_mdp']==$mdpSaisi)
            {
                $trouve = true ;
                $_SESSION['tl_login']=$ligne['tl_login'] ;
                $_SESSION['tl_droit']=$ligne['tl_droit'] ;
            }
        }
        else
        {
            $fin = true ;
        }
    }
    return $trouve ;
}

/**
 * Liste des tous les véhicules classés dans l'ordre alphabétique de la marque et du modèle
 
 * @param aucun
 * @return un curseur contenant l'ensemble des lignes à afficher
*/
function getLesVehicules() {
    require "connexion.php" ;
    $sql = "select mq_libelle, md_libelle, vh_km, vh_annee, vh_prix, vh_id "
            . "from vehicule "
            . "inner join modele on vh_md_id = md_id "
            . "inner join marque on md_mq_id = mq_id "
            . "order by mq_libelle, md_libelle" ;
    $exec=$bdd->query($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getLeVehicule($id) {
    require "connexion.php" ;
    $sql = "select * "
            . "from vehicule "
            . "inner join modele on vh_md_id = md_id "
            . "inner join energie on vh_ng_id = ng_id "
            . "inner join marque on md_mq_id = mq_id "
            . "where vh_id = $id " ;
    $exec=$bdd->query($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function getLesMarques(){
    require "connexion.php" ;
    $sql = "select mq_id, mq_libelle "
            . "from marque " 
            . "order by mq_libelle asc";
    $exec=$bdd->query($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll() ;
    return $curseur;
}

function ajouterMarque($marque){
    require "connexion.php" ;
    $sql = "insert into marque(mq_libelle) "
            . "values('$marque')" ;
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll() ;
    return $curseur;
}

function verifierDonblons($marque){
    require "connexion.php" ;
    $sql = "select mq_libelle "
            . "from marque "
            . "where mq_libelle = '$marque' " ;
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function modifierMarque($id, $marque){
    require "connexion.php" ;
    $sql = "update marque "
        . "set mq_libelle = '$marque' "
        . "where mq_id = $id " ;
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function supprVehicule($id){
    require "connexion.php" ;
    $sql = "delete "
        . "from vehicule "
        . "where vh_md_id in (select md_id from modele where md_mq_id = $id)" ;
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function supprModele($id){
    require "connexion.php" ;
    $sql = "delete "
        . "from modele "
        . "where md_mq_id = $id " ;
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function supprMarque($id){
    require "connexion.php" ;
    $sql = "delete "
        . "from marque "
        . "where mq_id = $id" ;
    $exec = $bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch() ;
    return $curseur;
}

function getLesModeles(){
    require "connexion.php";
    $sql = " select md_libelle "
            . "from modele " ;
    $exec = $bdd->prepare($sql) ;
    $exec =execute();
    $curseur=$exec->fetchAll();
    return $curseur;
}

?>